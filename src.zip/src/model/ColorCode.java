package model;

public enum ColorCode {
    RED, GREEN, BLUE
}
